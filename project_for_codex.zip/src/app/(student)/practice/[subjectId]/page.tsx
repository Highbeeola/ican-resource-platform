"use client";

import { useState, useEffect, useTransition, useRef, useCallback } from "react";
import { useParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { submitQuizAttempt } from "@/lib/actions/quiz";
import Link from "next/link";
import { toast } from "react-hot-toast";
import {
  ArrowLeft,
  CheckCircle2,
  Award,
  Loader2,
  Lightbulb,
  HelpCircle,
  Timer,
  AlertCircle,
  X,
  BookOpen,
} from "lucide-react";

export default function PracticeQuizPage() {
  const { subjectId } = useParams();
  const [questions, setQuestions] = useState<any[]>([]);
  const [subject, setSubject] = useState<any>(null);
  const [userAnswers, setUserAnswers] = useState<Record<string, string>>({});
  const [isPending, startTransition] = useTransition();
  const [result, setResult] = useState<any>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showConfirmModal, setShowConfirmModal] = useState(false);

  // Exercise selection states
  const [availableExercises, setAvailableExercises] = useState<string[]>([]);
  const [selectedExercise, setSelectedExercise] = useState<string | null>(null);

  // Timer states
  const [timeLeft, setTimeLeft] = useState<number>(0);
  const [isTimerRunning, setIsTimerRunning] = useState(false);

  // Ref to hold current userAnswers for auto-submit
  const userAnswersRef = useRef(userAnswers);
  useEffect(() => {
    userAnswersRef.current = userAnswers;
  }, [userAnswers]);

  // Fetch Subject and Available Exercise/Topic list
  useEffect(() => {
    const supabase = createClient();

    // Fetch Subject
    supabase
      .from("subjects")
      .select("*")
      .eq("id", subjectId)
      .single()
      .then(({ data }) => setSubject(data));

    // Fetch available exercise topics
    supabase
      .from("questions")
      .select("topic_name")
      .eq("subject_id", subjectId)
      .then(({ data, error }) => {
        if (error) console.error("Error fetching exercise list:", error);
        const unique = [
          ...new Set(data?.map((q) => q.topic_name).filter(Boolean)),
        ] as string[];
        setAvailableExercises(unique);
        setIsLoading(false);
      });
  }, [subjectId]);

  // Function to start a specific exercise/mock test
  function startExercise(exerciseName: string) {
    setIsLoading(true);
    setSelectedExercise(exerciseName);

    const supabase = createClient();
    supabase
      .from("questions")
      .select("*, question_options(*)")
      .eq("subject_id", subjectId)
      .eq("topic_name", exerciseName)
      .then(({ data, error }) => {
        if (error) console.error("Error fetching practice questions:", error);
        const fetchedQuestions = data || [];
        setQuestions(fetchedQuestions);
        setIsLoading(false);

        // Start timer: 90 seconds (1.5 minutes) per question
        if (fetchedQuestions.length > 0) {
          setTimeLeft(fetchedQuestions.length * 90);
          setIsTimerRunning(true);
        }
      });
  }

  // Submit Quiz Function
  const handleSubmitQuiz = useCallback(() => {
    setShowConfirmModal(false);
    setIsTimerRunning(false); // Stop timer
    startTransition(async () => {
      const res = await submitQuizAttempt(
        subjectId as string,
        questions.length,
        userAnswersRef.current,
      );

      if (res.success) {
        setResult(res);
        toast.success("Practice Test Graded!");
        window.scrollTo({ top: 0, behavior: "smooth" });
      } else {
        toast.error("Failed to submit quiz.");
      }
    });
  }, [subjectId, questions.length]);

  // Timer Countdown Logic
  useEffect(() => {
    if (!isTimerRunning || timeLeft <= 0) return;

    const timerId = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timerId);
          setIsTimerRunning(false);
          toast.error("Time is up! Auto-submitting your quiz...");
          handleSubmitQuiz(); // Auto-submit on expiration
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timerId);
  }, [isTimerRunning, timeLeft, handleSubmitQuiz]);

  // Format seconds into MM:SS
  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60)
      .toString()
      .padStart(2, "0");
    const s = (seconds % 60).toString().padStart(2, "0");
    return `${m}:${s}`;
  };

  function handleOptionSelect(questionId: string, optionId: string) {
    if (result) return; // Disable changing answers after submission
    setUserAnswers((prev) => ({ ...prev, [questionId]: optionId }));
  }

  const answeredCount = Object.keys(userAnswers).length;
  const unansweredCount = questions.length - answeredCount;

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 p-4 sm:p-6 md:p-10 relative">
      <div className="max-w-4xl mx-auto space-y-6">
        {/* BACK BUTTON */}
        <Link
          href={`/resources/subject/${subjectId}`}
          className="inline-flex items-center gap-2 text-xs sm:text-sm font-semibold text-slate-500 hover:text-[#1e3a8a] transition bg-white px-3.5 py-2 rounded-lg border border-slate-200 shadow-sm w-fit"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to {subject?.name || "Course"}</span>
        </Link>

        {/* HEADER SECTION */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#1e3a8a]">
              {subject?.name || "Subject"} Practice Test
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              {selectedExercise
                ? `Currently taking: ${selectedExercise}`
                : "Select an exercise or mock exam to start testing your knowledge."}
            </p>
          </div>
        </div>

        {/* FLOATING TIMER */}
        {!result && selectedExercise && questions.length > 0 && !isLoading && (
          <div
            className={`fixed bottom-6 right-6 sm:bottom-auto sm:top-20 sm:right-8 z-30 flex items-center gap-2 px-4 py-2.5 rounded-2xl border-2 shadow-xl font-mono text-base sm:text-lg font-bold transition-all ${
              timeLeft <= 60
                ? "bg-rose-50 border-rose-500 text-rose-600 animate-pulse"
                : "bg-white/95 backdrop-blur-md border-slate-200 text-[#1e3a8a]"
            }`}
          >
            <Timer className="w-5 h-5 text-[#f59e0b]" />
            <span>{formatTime(timeLeft)}</span>
          </div>
        )}

        {/* RESULTS BANNER */}
        {result && (
          <div
            className={`border-2 rounded-2xl p-6 sm:p-8 text-center space-y-3 shadow-sm transition-colors ${
              result.scorePercentage >= 70
                ? "bg-emerald-50 border-emerald-500 text-emerald-900"
                : result.scorePercentage >= 50
                  ? "bg-amber-50 border-amber-500 text-amber-900"
                  : "bg-rose-50 border-rose-500 text-rose-900"
            }`}
          >
            <Award
              className={`w-16 h-16 mx-auto ${
                result.scorePercentage >= 70
                  ? "text-emerald-500"
                  : result.scorePercentage >= 50
                    ? "text-amber-500"
                    : "text-rose-500"
              }`}
            />
            <h2 className="text-2xl font-extrabold">Quiz Completed!</h2>
            <p
              className={`font-black text-5xl ${
                result.scorePercentage >= 70
                  ? "text-emerald-600"
                  : result.scorePercentage >= 50
                    ? "text-amber-600"
                    : "text-rose-600"
              }`}
            >
              {result.scorePercentage}%
            </p>
            <p className="text-sm font-medium opacity-80">
              You answered {result.correctCount} out of {result.totalQuestions}{" "}
              questions correctly.
            </p>
            <button
              onClick={() => {
                setResult(null);
                setSelectedExercise(null);
                setQuestions([]);
                setUserAnswers({});
              }}
              className="mt-4 px-6 py-2.5 bg-[#1e3a8a] text-white font-bold rounded-xl text-xs sm:text-sm hover:bg-[#162c6d] transition shadow-sm cursor-pointer"
            >
              Back to Exercise List
            </button>
          </div>
        )}

        {/* LOADING STATE */}
        {isLoading ? (
          <div className="bg-white border border-slate-200 rounded-2xl p-12 flex flex-col items-center justify-center space-y-3 shadow-sm">
            <Loader2 className="w-8 h-8 text-[#f59e0b] animate-spin" />
            <p className="text-slate-500 font-medium">
              Loading practice test...
            </p>
          </div>
        ) : !selectedExercise && availableExercises.length > 0 ? (
          /* EXERCISE SELECTION LOBBY */
          <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-sm space-y-5">
            <div className="flex items-center gap-2 border-b border-slate-100 pb-4">
              <BookOpen className="w-5 h-5 text-[#f59e0b]" />
              <h3 className="text-lg font-bold text-[#1e3a8a]">
                Select a Practice Test / Exercise
              </h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {availableExercises.map((ex) => (
                <button
                  key={ex}
                  onClick={() => startExercise(ex)}
                  className="p-5 text-left border border-slate-200 rounded-xl hover:border-[#f59e0b] hover:shadow-md transition group bg-slate-50/50 hover:bg-white cursor-pointer"
                >
                  <h4 className="font-bold text-slate-900 group-hover:text-[#1e3a8a] text-base">
                    {ex}
                  </h4>
                  <p className="text-xs font-semibold text-slate-500 mt-2 flex items-center gap-1">
                    <span>Start timed test</span>
                    <span className="group-hover:translate-x-1 transition-transform">
                      →
                    </span>
                  </p>
                </button>
              ))}
            </div>
          </div>
        ) : !selectedExercise && availableExercises.length === 0 ? (
          /* EMPTY STATE */
          <div className="bg-white border border-dashed border-slate-300 rounded-2xl p-12 text-center space-y-3 shadow-sm">
            <div className="w-12 h-12 bg-blue-50 text-[#1e3a8a] rounded-xl flex items-center justify-center mx-auto">
              <HelpCircle className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-slate-900">
              No practice exercises available yet!
            </h3>
            <p className="text-xs sm:text-sm text-slate-500 max-w-sm mx-auto">
              The faculty has not added any exercises to this subject's question
              bank. Please check back later.
            </p>
          </div>
        ) : (
          /* QUESTIONS LIST (ACTIVE TEST) */
          <div className="space-y-6">
            {questions.map((q, qIdx) => (
              <div
                key={q.id}
                className="bg-white border border-slate-200 rounded-2xl p-6 shadow-sm space-y-4"
              >
                <div className="flex justify-between items-start gap-4 border-b border-slate-100 pb-3">
                  <span className="text-xs font-bold uppercase text-[#1e3a8a] px-3 py-1 bg-blue-50 rounded-md">
                    Question {qIdx + 1}
                  </span>
                  {q.topic_name && (
                    <span className="text-xs font-semibold text-slate-500 bg-slate-100 px-2 py-1 rounded">
                      {q.topic_name}
                    </span>
                  )}
                </div>

                <h3 className="font-bold text-slate-900 text-sm sm:text-base leading-snug">
                  {q.question_text}
                </h3>

                {/* OPTIONS */}
                <div className="space-y-2 pt-2">
                  {q.question_options?.map((opt: any) => {
                    const isSelected = userAnswers[q.id] === opt.id;
                    const isCorrect = opt.is_correct;

                    let optionStyle =
                      "bg-slate-50 border-slate-200 text-slate-700 hover:border-[#1e3a8a] hover:bg-blue-50";

                    if (isSelected) {
                      optionStyle =
                        "bg-blue-50 border-[#1e3a8a] text-[#1e3a8a] font-bold shadow-sm";
                    }

                    // REVEAL ANSWERS AFTER SUBMISSION
                    if (result) {
                      if (isCorrect) {
                        optionStyle =
                          "bg-emerald-50 border-emerald-500 text-emerald-700 font-bold";
                      } else if (isSelected && !isCorrect) {
                        optionStyle =
                          "bg-rose-50 border-rose-500 text-rose-700 font-bold";
                      } else {
                        optionStyle =
                          "bg-slate-50 border-slate-200 text-slate-400 opacity-60 cursor-not-allowed";
                      }
                    }

                    return (
                      <button
                        key={opt.id}
                        onClick={() => handleOptionSelect(q.id, opt.id)}
                        disabled={!!result}
                        className={`w-full text-left p-3.5 rounded-xl border text-xs sm:text-sm transition flex items-center justify-between ${
                          !result ? "cursor-pointer" : ""
                        } ${optionStyle}`}
                      >
                        <span>{opt.option_text}</span>
                        {isSelected && !result && (
                          <CheckCircle2 className="w-5 h-5 text-[#1e3a8a] flex-shrink-0" />
                        )}
                        {result && isCorrect && (
                          <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0" />
                        )}
                      </button>
                    );
                  })}
                </div>

                {/* EXPLANATION WHEN SUBMITTED */}
                {result && q.explanation && (
                  <div className="mt-4 p-4 bg-amber-50 border border-amber-200 rounded-xl text-xs sm:text-sm text-slate-700 space-y-1">
                    <span className="font-bold text-amber-600 flex items-center gap-1.5 mb-1">
                      <Lightbulb className="w-4 h-4" /> Solution Explanation:
                    </span>
                    <p className="leading-relaxed font-medium">
                      {q.explanation}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* SUBMIT BUTTON */}
        {!result && selectedExercise && questions.length > 0 && !isLoading && (
          <button
            onClick={() => setShowConfirmModal(true)}
            disabled={isPending || answeredCount === 0}
            className="w-full py-4 bg-[#f59e0b] hover:bg-[#d97706] text-white font-bold rounded-xl text-sm transition shadow-md flex items-center justify-center gap-2 disabled:opacity-50 cursor-pointer"
          >
            {isPending ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <span>Submit Practice Test</span>
            )}
          </button>
        )}
      </div>

      {/* SUBMISSION CONFIRMATION MODAL */}
      {showConfirmModal && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl border border-slate-100 space-y-5 animate-in fade-in zoom-in duration-150">
            <div className="flex justify-between items-start">
              <div className="w-10 h-10 bg-amber-50 rounded-xl flex items-center justify-center text-amber-600">
                <AlertCircle className="w-6 h-6" />
              </div>
              <button
                onClick={() => setShowConfirmModal(false)}
                className="text-slate-400 hover:text-slate-600 p-1 rounded-lg hover:bg-slate-100 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div>
              <h3 className="text-lg font-bold text-slate-900">
                Submit Practice Test?
              </h3>
              <p className="text-xs sm:text-sm text-slate-500 mt-1 leading-relaxed">
                Are you sure you want to finalize your submission? You won't be
                able to change your answers after submitting.
              </p>
            </div>

            {/* ANSWER SUMMARY BOX */}
            <div className="bg-slate-50 border border-slate-200 rounded-xl p-3.5 flex items-center justify-around text-center text-xs sm:text-sm font-semibold">
              <div>
                <p className="text-emerald-600 font-bold text-base">
                  {answeredCount}
                </p>
                <p className="text-slate-500 text-[11px]">Answered</p>
              </div>
              <div className="h-8 w-px bg-slate-200" />
              <div>
                <p
                  className={`font-bold text-base ${unansweredCount > 0 ? "text-rose-500" : "text-slate-400"}`}
                >
                  {unansweredCount}
                </p>
                <p className="text-slate-500 text-[11px]">Unanswered</p>
              </div>
            </div>

            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={() => setShowConfirmModal(false)}
                className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs sm:text-sm transition cursor-pointer"
              >
                Continue Quiz
              </button>
              <button
                onClick={handleSubmitQuiz}
                disabled={isPending}
                className="flex-1 py-2.5 bg-[#f59e0b] hover:bg-[#d97706] text-white font-bold rounded-xl text-xs sm:text-sm transition shadow-sm flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isPending ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <span>Yes, Submit</span>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
