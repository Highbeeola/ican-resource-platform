"use client";

import { useState, useEffect, useRef } from "react";
import { usePathname } from "next/navigation";
import Link from "next/link";
import {
  LogOut,
  Shield,
  Menu,
  X,
  Home,
  BookOpen,
  ChevronDown,
  User as UserIcon,
  Settings,
  Target,
  LayoutDashboard,
  FileText,
  Info,
  Mail,
  Bell,
} from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import BrandLogo from "@/components/BrandLogo";

export default function Navbar() {
  const pathname = usePathname();
  const [user, setUser] = useState<any>(null);
  const [isAdmin, setIsAdmin] = useState<boolean>(false);
  const [isChecking, setIsChecking] = useState<boolean>(true);
  const [unreadCount, setUnreadCount] = useState<number>(0);
  const [streak, setStreak] = useState<number>(0);
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState<boolean>(false);
  const [moreDropdownOpen, setMoreDropdownOpen] = useState<boolean>(false);

  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node)
      ) {
        setUserDropdownOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Fetch User, Role, Notifications, and Day Streak
  useEffect(() => {
    const supabase = createClient();

    async function checkUserAndNotifications(sessionUser: any) {
      setUser(sessionUser);

      if (sessionUser) {
        // Fetch user profile role and true daily streak
        const { data: profile } = await supabase
          .from("profiles")
          .select("role, current_streak")
          .eq("id", sessionUser.id)
          .single();

        setIsAdmin(profile?.role === "admin");
        setStreak(profile?.current_streak || 0);

        // Fetch unread notifications count
        const { count: totalNotes } = await supabase
          .from("announcements")
          .select("id", { count: "exact", head: true })
          .eq("is_published", true);

        const { count: readNotes } = await supabase
          .from("user_notification_reads")
          .select("announcement_id", { count: "exact", head: true })
          .eq("user_id", sessionUser.id);

        const unread = (totalNotes || 0) - (readNotes || 0);
        setUnreadCount(unread > 0 ? unread : 0);
      } else {
        setIsAdmin(false);
        setUnreadCount(0);
        setStreak(0);
      }

      setIsChecking(false);
    }

    supabase.auth
      .getUser()
      .then(({ data }) => checkUserAndNotifications(data.user));

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) =>
      checkUserAndNotifications(session?.user ?? null),
    );

    return () => subscription.unsubscribe();
  }, [pathname]);

  useEffect(() => {
    setMobileMenuOpen(false);
    setUserDropdownOpen(false);
    setMoreDropdownOpen(false);
  }, [pathname]);

  if (
    pathname === "/login" ||
    pathname === "/register" ||
    pathname === "/admin/login" ||
    pathname === "/forgot-password" ||
    pathname === "/update-password"
  ) {
    return null;
  }

  const handleLogout = async () => {
    if (!window.confirm("Are you sure you want to log out?")) {
      return;
    }
    const supabase = createClient();
    await supabase.auth.signOut();
    setUser(null);
    window.location.href = "/login";
  };

  const isActive = (path: string) => pathname === path;

  return (
    <>
      <header className="bg-white/95 backdrop-blur-md border-b border-slate-200 text-slate-900 sticky top-0 z-40 transition-all">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <Link href="/" className="flex-shrink-0">
            <BrandLogo />
          </Link>

          {/* DESKTOP NAVIGATION */}
          <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
            <Link
              href="/"
              className={`transition hover:text-[#1e3a8a] ${
                isActive("/") ? "text-[#1e3a8a] font-semibold" : ""
              }`}
            >
              Home
            </Link>
            <Link
              href="/resources"
              className={`transition hover:text-[#1e3a8a] ${
                isActive("/resources") ? "text-[#1e3a8a] font-semibold" : ""
              }`}
            >
              Courses
            </Link>

            {user && (
              <>
                <Link
                  href="/resources?type=pathfinder"
                  className="hover:text-[#1e3a8a] transition"
                >
                  Pathfinders
                </Link>
                <Link
                  href="/resources?type=past_question"
                  className="hover:text-[#1e3a8a] transition"
                >
                  Past Questions
                </Link>
              </>
            )}

            <div
              className="relative"
              onMouseLeave={() => setMoreDropdownOpen(false)}
            >
              <button
                onMouseEnter={() => setMoreDropdownOpen(true)}
                onClick={() => setMoreDropdownOpen(!moreDropdownOpen)}
                className="flex items-center gap-1 hover:text-[#1e3a8a] transition py-2 focus:outline-none cursor-pointer"
              >
                <span>More</span>
                <ChevronDown className="w-4 h-4" />
              </button>

              {moreDropdownOpen && (
                <div className="absolute top-full left-0 w-44 bg-white rounded-xl shadow-xl border border-slate-200/80 py-2 text-slate-700 z-50">
                  {user && (
                    <Link
                      href="/lecturers"
                      className="block px-4 py-2 text-sm hover:bg-slate-50 hover:text-[#1e3a8a] transition"
                    >
                      Faculty
                    </Link>
                  )}
                  <Link
                    href="/about"
                    className="block px-4 py-2 text-sm hover:bg-slate-50 hover:text-[#1e3a8a] transition"
                  >
                    About Us
                  </Link>
                  <Link
                    href="/contact"
                    className="block px-4 py-2 text-sm hover:bg-slate-50 hover:text-[#1e3a8a] transition"
                  >
                    Contact
                  </Link>
                </div>
              )}
            </div>
          </nav>

          {/* DESKTOP AUTH / USER MENU */}
          <div className="hidden md:flex items-center gap-3">
            {isChecking ? (
              <div className="w-32 h-10" />
            ) : !user ? (
              <>
                <Link
                  href="/login"
                  className="text-sm font-bold bg-[#1e3a8a] hover:bg-blue-900 active:scale-95 text-white px-5 py-2 rounded-lg transition shadow-sm"
                >
                  Login
                </Link>
                <Link
                  href="/register"
                  className="text-sm font-semibold text-slate-700 border border-slate-300 hover:bg-slate-50 active:scale-95 px-5 py-2 rounded-lg transition"
                >
                  Register Free
                </Link>
              </>
            ) : (
              <div
                className="relative flex items-center gap-3"
                ref={dropdownRef}
              >
                {isAdmin && (
                  <Link
                    href="/admin/resources"
                    className="text-xs font-semibold bg-slate-100 hover:bg-slate-200 text-slate-800 px-3 py-1.5 rounded-lg border border-slate-300 flex items-center gap-1.5 transition"
                  >
                    <Shield className="w-3.5 h-3.5 text-[#1e3a8a]" />
                    <span>Admin</span>
                  </Link>
                )}

                {/* DAY STREAK PILL */}
                <div
                  className="flex items-center gap-1.5 px-3 py-1 bg-amber-50 border border-amber-200/80 rounded-full shadow-xs cursor-default"
                  title={`${streak} day streak`}
                >
                  <span
                    className="text-base leading-none"
                    style={{
                      textShadow: "0 0 8px rgba(245, 158, 11, 0.4)",
                    }}
                  >
                    🔥
                  </span>
                  <span className="text-amber-900 text-xs font-extrabold">
                    {streak}
                  </span>
                </div>

                <Link
                  href="/notifications"
                  className="relative p-2 text-slate-600 hover:text-[#1e3a8a] hover:bg-slate-100 rounded-full transition"
                  title="Notifications"
                >
                  <Bell className="w-5 h-5" />
                  {unreadCount > 0 && (
                    <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-rose-500 rounded-full animate-pulse border-2 border-white" />
                  )}
                </Link>

                <button
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="w-9 h-9 rounded-full bg-slate-100 border border-slate-300 flex items-center justify-center text-slate-700 hover:bg-slate-200 transition cursor-pointer focus:outline-none"
                >
                  <UserIcon className="w-5 h-5 text-slate-600" />
                </button>

                {userDropdownOpen && (
                  <div className="absolute top-full right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-slate-200/80 py-2 text-slate-700 z-50">
                    <div className="px-4 py-2 border-b border-slate-100 mb-1">
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                        Signed in as
                      </p>
                      <p className="text-sm font-bold text-[#1e3a8a] truncate">
                        {user.email}
                      </p>
                    </div>
                    <Link
                      href="/dashboard"
                      className="flex items-center gap-2 px-4 py-2 text-sm hover:bg-slate-50 hover:text-[#1e3a8a] transition"
                    >
                      <LayoutDashboard className="w-4 h-4" /> Dashboard
                    </Link>
                    <Link
                      href="/performance"
                      className="flex items-center gap-2 px-4 py-2 text-sm hover:bg-slate-50 hover:text-[#1e3a8a] transition"
                    >
                      <Target className="w-4 h-4" /> Performance Analytics
                    </Link>
                    <Link
                      href="/settings"
                      className="flex items-center gap-2 px-4 py-2 text-sm hover:bg-slate-50 hover:text-[#1e3a8a] transition"
                    >
                      <Settings className="w-4 h-4" /> Settings
                    </Link>
                    <div className="border-t border-slate-100 mt-1 pt-1">
                      <button
                        onClick={handleLogout}
                        className="w-full flex items-center gap-2 px-4 py-2 text-sm hover:bg-rose-50 text-rose-600 transition text-left font-medium cursor-pointer"
                      >
                        <LogOut className="w-4 h-4" /> Logout
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* MOBILE HAMBURGER BUTTON */}
          <div className="flex md:hidden items-center gap-2">
            {user && (
              <div
                className="flex items-center gap-1 px-2.5 py-1 bg-amber-50 border border-amber-200/80 rounded-full shadow-xs cursor-default"
                title={`${streak} day streak`}
              >
                <span className="text-sm leading-none">🔥</span>
                <span className="text-amber-900 text-xs font-extrabold">
                  {streak}
                </span>
              </div>
            )}
            <button
              onClick={() => setMobileMenuOpen(true)}
              className="p-2 text-slate-600 hover:text-slate-900 focus:outline-none cursor-pointer rounded-lg hover:bg-slate-100 transition"
              aria-label="Open Menu"
            >
              <Menu className="w-6 h-6" />
            </button>
          </div>
        </div>
      </header>

      {/* FULL-SCREEN MOBILE NAVIGATION SHEET */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 md:hidden bg-white flex flex-col justify-between h-dvh">
          {/* TOP HEADER */}
          <div className="px-4 h-16 flex items-center justify-between border-b border-slate-200 flex-shrink-0 bg-white">
            <Link href="/" onClick={() => setMobileMenuOpen(false)}>
              <BrandLogo />
            </Link>
            <button
              onClick={() => setMobileMenuOpen(false)}
              className="p-2 text-slate-500 hover:text-slate-800 focus:outline-none rounded-full hover:bg-slate-100 transition cursor-pointer"
              aria-label="Close Menu"
            >
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* SCROLLABLE NAV BODY */}
          <div className="px-5 py-3 flex-1 overflow-y-auto max-h-[calc(100vh-14rem)] space-y-4 bg-white">
            <nav className="flex flex-col gap-0.5 text-base">
              <span className="text-[10px] font-bold tracking-wider text-slate-400 uppercase px-3 mb-1">
                Main Navigation
              </span>
              <Link
                href="/"
                className={`p-2.5 rounded-xl flex items-center gap-3 transition font-medium text-sm ${
                  isActive("/")
                    ? "bg-blue-50/80 text-[#1e3a8a] font-bold"
                    : "text-slate-700 hover:bg-slate-50"
                }`}
              >
                <Home className="w-4 h-4 text-slate-400" /> Home
              </Link>
              <Link
                href="/resources"
                className={`p-2.5 rounded-xl flex items-center gap-3 transition font-medium text-sm ${
                  isActive("/resources")
                    ? "bg-blue-50/80 text-[#1e3a8a] font-bold"
                    : "text-slate-700 hover:bg-slate-50"
                }`}
              >
                <BookOpen className="w-4 h-4 text-slate-400" /> Courses
              </Link>

              {user && (
                <>
                  <Link
                    href="/resources?type=pathfinder"
                    className="p-2.5 rounded-xl text-slate-700 hover:bg-slate-50 flex items-center gap-3 font-medium text-sm transition"
                  >
                    <FileText className="w-4 h-4 text-slate-400" /> Pathfinders
                  </Link>
                  <Link
                    href="/resources?type=past_question"
                    className="p-2.5 rounded-xl text-slate-700 hover:bg-slate-50 flex items-center gap-3 font-medium text-sm transition"
                  >
                    <FileText className="w-4 h-4 text-slate-400" /> Past
                    Questions
                  </Link>

                  <div className="border-t border-slate-100 my-2" />

                  <span className="text-[10px] font-bold tracking-wider text-slate-400 uppercase px-3 mb-1">
                    Account & Analytics
                  </span>
                  <Link
                    href="/dashboard"
                    className={`p-2.5 rounded-xl flex items-center gap-3 transition font-medium text-sm ${
                      isActive("/dashboard")
                        ? "bg-blue-50/80 text-[#1e3a8a] font-bold"
                        : "text-slate-700 hover:bg-slate-50"
                    }`}
                  >
                    <LayoutDashboard className="w-4 h-4 text-slate-400" />{" "}
                    Dashboard
                  </Link>
                  <Link
                    href="/notifications"
                    className="p-2.5 rounded-xl text-slate-700 hover:bg-slate-50 flex items-center justify-between font-medium text-sm transition"
                  >
                    <div className="flex items-center gap-3">
                      <Bell className="w-4 h-4 text-slate-400" /> Notifications
                    </div>
                    {unreadCount > 0 && (
                      <span className="bg-rose-500 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                        {unreadCount}
                      </span>
                    )}
                  </Link>
                  <Link
                    href="/performance"
                    className="p-2.5 rounded-xl text-slate-700 hover:bg-slate-50 flex items-center gap-3 font-medium text-sm transition"
                  >
                    <Target className="w-4 h-4 text-slate-400" /> Performance
                    Analytics
                  </Link>

                  <div className="border-t border-slate-100 my-2" />
                </>
              )}

              <span className="text-[10px] font-bold tracking-wider text-slate-400 uppercase px-3 mb-1">
                Company
              </span>
              {user && (
                <Link
                  href="/lecturers"
                  className="p-2.5 rounded-xl text-slate-700 hover:bg-slate-50 flex items-center gap-3 font-medium text-sm transition"
                >
                  <UserIcon className="w-4 h-4 text-slate-400" /> Faculty
                  Directory
                </Link>
              )}
              <Link
                href="/about"
                className="p-2.5 rounded-xl text-slate-700 hover:bg-slate-50 flex items-center gap-3 font-medium text-sm transition"
              >
                <Info className="w-4 h-4 text-slate-400" /> About Us
              </Link>
              <Link
                href="/contact"
                className="p-2.5 rounded-xl text-slate-700 hover:bg-slate-50 flex items-center gap-3 font-medium text-sm transition"
              >
                <Mail className="w-4 h-4 text-slate-400" /> Contact
              </Link>
            </nav>
          </div>

          {/* PINNED BOTTOM FOOTER */}
          <div className="p-4 pb-[calc(1rem+env(safe-area-inset-bottom))] border-t border-slate-200 bg-white flex-shrink-0 mt-auto">
            {isChecking ? (
              <div className="h-10 w-full" />
            ) : user ? (
              <div className="space-y-2.5">
                <div className="px-1 text-xs text-slate-500 flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 flex-shrink-0" />
                  <span className="truncate">
                    Signed in as{" "}
                    <strong className="text-slate-800">{user.email}</strong>
                  </span>
                </div>
                <button
                  type="button"
                  onClick={handleLogout}
                  className="w-full py-2.5 bg-rose-50 hover:bg-rose-100/80 active:bg-rose-200 text-rose-600 rounded-xl text-sm font-bold flex items-center justify-center gap-2 transition cursor-pointer border border-rose-200"
                >
                  <LogOut className="w-4 h-4" /> Logout
                </button>
              </div>
            ) : (
              <div className="flex flex-col gap-2">
                <Link
                  href="/login"
                  className="w-full py-2.5 text-center bg-[#1e3a8a] text-white rounded-xl text-sm font-bold shadow-sm hover:bg-blue-900 transition"
                >
                  Login
                </Link>
                <Link
                  href="/register"
                  className="w-full py-2.5 text-center bg-white text-slate-700 border border-slate-200 rounded-xl text-sm font-bold shadow-sm hover:bg-slate-50 transition"
                >
                  Register Free
                </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </>
  );
}
