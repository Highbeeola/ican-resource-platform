"use client";

import { useState, useEffect, useTransition } from "react";
import {
  createAnnouncement,
  deleteAnnouncement,
  getAllAnnouncements,
} from "@/lib/actions/announcements";
import { Megaphone, Loader2, Trash2 } from "lucide-react";
import toast from "react-hot-toast";

export default function AddAnnouncementForm() {
  const [isPending, startTransition] = useTransition();
  const [announcements, setAnnouncements] = useState<any[]>([]);

  // Fetch active announcements list
  useEffect(() => {
    getAllAnnouncements().then(setAnnouncements);
  }, []);

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();

    const form = e.currentTarget;
    const formData = new FormData(form);

    startTransition(async () => {
      const res = await createAnnouncement(formData);
      if (res?.error) {
        toast.error(res.error);
      } else {
        toast.success("Announcement banner published live!");
        form.reset();
        const updated = await getAllAnnouncements();
        setAnnouncements(updated);
      }
    });
  }

  function handleDelete(id: string) {
    startTransition(async () => {
      const res = await deleteAnnouncement(id);
      if (res?.success) {
        toast.success("Announcement banner removed from website!");
        const updated = await getAllAnnouncements();
        setAnnouncements(updated);
      } else if (res?.error) {
        toast.error(res.error);
      }
    });
  }

  return (
    <div className="space-y-6">
      {/* CREATION FORM */}
      <form
        onSubmit={handleSubmit}
        className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 space-y-4 text-slate-900 shadow-sm"
      >
        <h2 className="font-bold text-[#1e3a8a] text-base border-b border-slate-100 pb-3 flex items-center gap-2">
          <Megaphone className="w-5 h-5 text-[#1e3a8a]" />
          <span>Post Exam Broadcast Announcement</span>
        </h2>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Announcement Title *
          </label>
          <input
            type="text"
            name="title"
            required
            placeholder="e.g. MAY 2026 ICAN DIET EXAM DATES"
            className="w-full px-4 py-2.5 bg-white border border-slate-200 text-slate-900 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-[#1e3a8a] transition"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Content / Message *
          </label>
          <textarea
            name="content"
            rows={3}
            required
            placeholder="e.g. Registration for May 2026 Diet closes on April 15th."
            className="w-full px-4 py-2.5 bg-white border border-slate-200 text-slate-900 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-[#1e3a8a] transition"
          ></textarea>
        </div>

        {/* DATE RANGE FIELDS */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Start Date (Optional)
            </label>
            <input
              type="date"
              name="start_date"
              className="w-full px-4 py-2.5 bg-white border border-slate-200 text-slate-900 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-[#1e3a8a] transition"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              End Date (Optional)
            </label>
            <input
              type="date"
              name="end_date"
              className="w-full px-4 py-2.5 bg-white border border-slate-200 text-slate-900 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#1e3a8a] focus:border-[#1e3a8a] transition"
            />
          </div>
        </div>

        <button
          type="submit"
          disabled={isPending}
          className="bg-[#1e3a8a] hover:bg-blue-900 text-white font-bold px-6 py-3 rounded-xl text-sm transition cursor-pointer disabled:opacity-50 flex items-center gap-2 shadow-sm"
        >
          {isPending ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-white" />
              <span>Publishing...</span>
            </>
          ) : (
            <span>Publish Announcement Banner</span>
          )}
        </button>
      </form>

      {/* ACTIVE ANNOUNCEMENTS LIST */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 space-y-4 shadow-sm">
        <h3 className="font-bold text-[#1e3a8a] text-base border-b border-slate-100 pb-3">
          Published Announcements ({announcements.length})
        </h3>

        <div className="divide-y divide-slate-100">
          {announcements.length === 0 ? (
            <p className="text-xs text-slate-400 py-4">
              No active announcement banners.
            </p>
          ) : (
            announcements.map((item) => (
              <div
                key={item.id}
                className="py-3 flex justify-between items-center text-xs sm:text-sm"
              >
                <div>
                  <p className="font-bold text-slate-900 uppercase">
                    {item.title}
                  </p>
                  <p className="text-slate-600 text-xs mt-0.5">
                    {item.content}
                  </p>
                </div>
                <button
                  onClick={() => handleDelete(item.id)}
                  disabled={isPending}
                  className="px-3 py-1.5 bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 rounded-lg text-xs font-semibold flex items-center gap-1 transition cursor-pointer disabled:opacity-50"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Remove Banner</span>
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
