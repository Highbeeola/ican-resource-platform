"use client";

import { useTransition } from "react";
import { Level } from "@/types";
import { createSubject } from "@/lib/actions/subjects";
import { Plus, Loader2 } from "lucide-react";
import toast from "react-hot-toast";

interface Props {
  levels: Level[];
}

export default function AddSubjectForm({ levels }: Props) {
  const [isPending, startTransition] = useTransition();

  function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();

    const form = e.currentTarget;
    const formData = new FormData(form);

    startTransition(async () => {
      const res = await createSubject(formData);
      if (res?.error) {
        toast.error(res.error);
      } else {
        toast.success("Subject & Lecturer details saved successfully!");
        form.reset();
      }
    });
  }

  return (
    <form
      onSubmit={handleSubmit}
      className="bg-white border border-slate-200 rounded-2xl p-4 sm:p-8 space-y-6 shadow-sm text-slate-900 w-full overflow-hidden"
    >
      <h2 className="text-base sm:text-lg font-bold text-[#1e3a8a] border-b border-slate-100 pb-3">
        Add New Course / Subject
      </h2>

      {/* INPUT GRID */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            ICAN Level *
          </label>
          <select
            name="level_id"
            required
            className="w-full px-4 py-2.5 bg-white border border-slate-200 text-slate-900 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition"
          >
            <option value="">Select Level</option>
            {levels.map((lvl: Level) => (
              <option key={lvl.id} value={lvl.id}>
                {lvl.programme?.name ? `${lvl.programme.name} - ` : ""}
                {lvl.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Subject Name *
          </label>
          <input
            type="text"
            name="name"
            required
            placeholder="e.g. Financial Reporting"
            className="w-full px-4 py-2.5 bg-white border border-slate-200 text-slate-900 placeholder:text-slate-400 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Lecturer / Instructor Name
          </label>
          <input
            type="text"
            name="instructor_name"
            placeholder="e.g. CA Rajesh Kumar"
            className="w-full px-4 py-2.5 bg-white border border-slate-200 text-slate-900 placeholder:text-slate-400 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Subject Code
          </label>
          <input
            type="text"
            name="code"
            placeholder="e.g. FR"
            className="w-full px-4 py-2.5 bg-white border border-slate-200 text-slate-900 placeholder:text-slate-400 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition"
          />
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Estimated Course Hours
          </label>
          <input
            type="number"
            name="estimated_hours"
            placeholder="e.g. 40"
            className="w-full px-4 py-2.5 bg-white border border-slate-200 text-slate-900 placeholder:text-slate-400 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition"
          />
        </div>

        {/* FIXED DATE INPUTS FOR SAFARI & MOBILE */}
        <div className="w-full min-w-0">
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Course Start Date
          </label>
          <input
            type="date"
            name="start_date"
            className="w-full max-w-full min-h-[42px] px-4 py-2.5 bg-white border border-slate-200 text-slate-900 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition appearance-none"
          />
        </div>

        <div className="w-full min-w-0">
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Course End Date
          </label>
          <input
            type="date"
            name="end_date"
            className="w-full max-w-full min-h-[42px] px-4 py-2.5 bg-white border border-slate-200 text-slate-900 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition appearance-none"
          />
        </div>

        {/* GOOGLE MEET & SCHEDULE FIELDS */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Google Meet Link (Optional)
          </label>
          <input
            type="url"
            name="meet_url"
            placeholder="https://meet.google.com/xxx-xxxx-xxx"
            className="w-full px-4 py-2.5 bg-white border border-slate-200 text-slate-900 placeholder:text-slate-400 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition"
          />
        </div>

        <div className="sm:col-span-2 lg:col-span-3">
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Live Class Schedule (Optional)
          </label>
          <input
            type="text"
            name="meet_time"
            placeholder="e.g. Every Saturday at 10:00 AM"
            className="w-full px-4 py-2.5 bg-white border border-slate-200 text-slate-900 placeholder:text-slate-400 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition"
          />
        </div>
      </div>

      <div>
        <label className="block text-xs font-semibold text-slate-700 mb-1">
          Course Description
        </label>
        <textarea
          name="description"
          rows={2}
          placeholder="Brief overview of accounting concepts covered..."
          className="w-full px-4 py-2.5 bg-white border border-slate-200 text-slate-900 placeholder:text-slate-400 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-amber-500 focus:border-amber-500 transition"
        ></textarea>
      </div>

      <button
        type="submit"
        disabled={isPending}
        className="w-full sm:w-auto bg-amber-500 hover:bg-amber-600 text-white font-bold px-6 py-3 rounded-xl text-sm flex items-center justify-center gap-2 transition shadow-sm disabled:opacity-50 cursor-pointer"
      >
        {isPending ? (
          <>
            <Loader2 className="w-4 h-4 animate-spin text-white" />
            <span>Saving Course...</span>
          </>
        ) : (
          <>
            <Plus className="w-4 h-4" />
            <span>Save Subject & Lecturer</span>
          </>
        )}
      </button>
    </form>
  );
}
